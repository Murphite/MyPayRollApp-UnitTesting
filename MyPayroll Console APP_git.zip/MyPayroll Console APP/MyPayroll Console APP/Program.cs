﻿using MyPayroll.Data;
using MyPayroll.Model;
using MyPayroll.Logic;
using System;
using System.Globalization;

namespace PayrollManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            PayrollLogic payrollLogic = new PayrollLogic();
            bool option = true;

            try
            {
                while (option)
                {
                    Console.Clear();
                    Console.WriteLine("Welcome to Decagon's Payroll Management System\n");
                    Console.WriteLine("----------------------------------------------------");
                    Console.WriteLine();

                    Console.WriteLine("Employees Payroll Operations");
                    Console.WriteLine();

                    // Gather input from the user
                    Console.Write("Kindly Enter Employee's Name: ");
                    string name = Console.ReadLine(); // Changed variable name to lowercase

                    bool activeStatus;
                    while (true)
                    {
                        Console.Write("Is Employee Active (true/false): \n");
                        if (!bool.TryParse(Console.ReadLine(), out activeStatus))
                        {
                            Console.WriteLine("Invalid input for active status. Please enter 'true' or 'false'.");
                        }
                        else
                        {
                            break; // Removed unnecessary "true;"
                        }
                    }

                    int overtimeHours;
                    while (true)
                    {
                        Console.Write("Enter Employee's Overtime Hours: \n");
                        if (!int.TryParse(Console.ReadLine(), out overtimeHours))
                        {
                            Console.WriteLine("Invalid input for overtime hours. Please enter a valid integer.");
                        }
                        else
                        {
                            break;
                        }
                    }

                    int regularHours;
                    while (true)
                    {
                        Console.Write("Enter Employee's Regular Hours: \n");
                        if (!int.TryParse(Console.ReadLine(), out regularHours))
                        {
                            Console.WriteLine("Invalid input for regular hours. Please enter a valid integer.");
                        }
                        else
                        {
                            break;
                        }
                    }

                    DateTime startDate;
                    while (true)
                    {
                        Console.Write("What is Employee's Start Date (DD/MM/YY): \n");
                        if (DateTime.TryParseExact(Console.ReadLine(), "dd/MM/yy", CultureInfo.InvariantCulture, DateTimeStyles.None, out startDate))
                            break;
                        else
                            Console.WriteLine("Invalid date format. Please enter a date in DD/MM/YY format.");
                    }


                    DateTime endDate;
                    while (true)
                    {
                        Console.Write("What is Employee's End Date (DD/MM/YY): \n");
                        if (DateTime.TryParseExact(Console.ReadLine(), "dd/MM/yy", CultureInfo.InvariantCulture, DateTimeStyles.None, out endDate))
                            break;
                        else
                            Console.WriteLine("Invalid date format. Please enter a date in DD/MM/YY format.");
                    }

                    DateTime payDate;
                    while (true)
                    {
                        Console.Write("Pay Date (DD/MM/YY): \n");
                        if (DateTime.TryParseExact(Console.ReadLine(), "dd/MM/yy", CultureInfo.InvariantCulture, DateTimeStyles.None, out payDate))
                            break;
                        else
                            Console.WriteLine("Invalid date format. Please enter a date in DD/MM/YY format.");
                    }

                    Employee employee = new Employee()
                    {
                        EmployeeName = name, // Changed variable name to lowercase
                        ActiveStatus = activeStatus,
                        OvertimeHours = overtimeHours,
                        RegularHours = regularHours,
                        StartDate = startDate,
                        EndDate = endDate,
                        PayDate = payDate
                    };
                    payrollLogic.AddEmployee(employee);

                    Console.WriteLine("Successfully Saved Record");
                    Console.WriteLine("Thank you");
                    Console.WriteLine();

                    Console.WriteLine("Do you wish to continue? Y/N");
                    var ans = Console.ReadLine().ToUpper();
                    if (ans.Equals("N"))
                        option = false;
                }

                Console.WriteLine();

                Console.WriteLine("Would you like to print your payroll? Y/N");
                var answer = Console.ReadLine().ToUpper();
                if (answer.Equals("N"))
                    Environment.Exit(0);

                // Else print table
                payrollLogic.PrintEmployeeInfo();
                Console.WriteLine();
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("Record(s) Saved and Printed from InMemory.");
            }
        }

    }
}
