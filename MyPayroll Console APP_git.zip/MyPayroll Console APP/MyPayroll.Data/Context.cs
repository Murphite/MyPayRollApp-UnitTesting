﻿
using MyPayroll.Model;

namespace MyPayroll.Data
{
    public  class Context
    {
        

        Employee newEmployee = new Employee();

        private List<Employee> newEmployees = new List<Employee>();

        public void AddEmployee(Employee employee)
        {
            newEmployees.Add(employee);
        }


        public List<Employee> GetAllEmployees()
        {
            return newEmployees;
        }

    }
}