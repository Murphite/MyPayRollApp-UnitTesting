﻿using MyPayroll.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPayroll.Logic.Interfaces
{
    public interface IPayRollCalculator
    {
        void CalculatePay(Employee employee);
    }
}
