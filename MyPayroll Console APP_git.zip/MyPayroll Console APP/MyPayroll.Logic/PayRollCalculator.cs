﻿using MyPayroll.Logic.Interfaces;
using MyPayroll.Model;
using System;
using MyPayroll.Logic;


namespace MyPayroll.Logic
{
    public class PayRollCalculator : IPayRollCalculator
    {
        public void CalculatePay(Employee employee)
        {
            if (employee.ActiveStatus)
            {
                employee.GrossPay = (employee.RegularHours * employee.RegularRate) + (employee.OvertimeHours * employee.OvertimeRate);


                employee.MedicareDeduction = employee.MedicareRate * employee.GrossPay;
                employee.FoodDeduction = employee.FoodRate * employee.GrossPay;
                employee.RentDeduction = employee.RentRate * employee.GrossPay;


                employee.NetPay = employee.GrossPay - (employee.MedicareDeduction + employee.FoodDeduction + employee.RentDeduction);
            }
        }
    }
}
