﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPayroll.Model
{
    public class Employee : BaseEntity
    {
        public string EmployeeName { get; set; } = "";     

        public bool ActiveStatus { get; set; } = false;
        public int OvertimeHours { get; set; }

        public int RegularHours { get; set; }
        public double GrossPay { get; set; }
        public double NetPay { get; set; }
        public double MedicareDeduction { get; set; }
        public double RentDeduction { get; set; }
        public double FoodDeduction { get; set; }
        public double RegularRate { get; set; } = 2500; // Default values
        public double OvertimeRate { get; set; } = 3000; // Default values
        public double MedicareRate { get; } = 0.02; // Default values (2%)
        public double RentRate { get; } = 0.05; // Default values (5%)
        public double FoodRate { get; } = 0.03; // Default values (3%)

    }
}
