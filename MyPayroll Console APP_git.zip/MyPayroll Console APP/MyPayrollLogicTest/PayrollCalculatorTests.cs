using Xunit;
using MyPayroll;
using MyPayroll.Logic;
using MyPayroll.Model;
using MyPayrollLogicTest;
using System.Numerics;
using System;

namespace MyPayrollLogicTest
{
    public class PayrollCalculatorTests
    {   

        [Fact]
        public void CalculatePay_ActiveStatusTrue_CalculatesPayCorrectly()
        {
            // Arrange
            var calculator = new PayRollCalculator();  // create an instance of PayRollCalculator
            var employee = new Employee
            {
                ActiveStatus = true,
                RegularHours = 40, // Sample values
                RegularRate = 2500,
                OvertimeHours = 10,
                OvertimeRate = 3000              
            };

            // Act
            calculator.CalculatePay(employee);

            // Assert
            Assert.Equal(130000, employee.GrossPay);
            Assert.Equal(2600, employee.MedicareDeduction);
            Assert.Equal(3900, employee.FoodDeduction);
            Assert.Equal(6500, employee.RentDeduction);
            Assert.Equal(117000, employee.NetPay);
        }

        [Fact]
        public void CalculatePay_ActiveStatusFalse_DoesNotCalculatePay()
        {
            // Arrange
            var calculator = new PayRollCalculator();
            var employee = new Employee
            {
                ActiveStatus = false,
                RegularHours = 40,
                RegularRate = 2500,
                OvertimeHours = 10,
                OvertimeRate = 3000               
            };

            // Act
            calculator.CalculatePay(employee);

            // Assert
            // Verify that the employee's properties haven't changed.
            Assert.Equal(0, employee.GrossPay);
            Assert.Equal(0, employee.MedicareDeduction);
            Assert.Equal(0, employee.FoodDeduction);
            Assert.Equal(0, employee.RentDeduction);
            Assert.Equal(0, employee.NetPay);
        }         
    }
}   
